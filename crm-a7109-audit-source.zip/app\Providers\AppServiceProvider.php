<?php

namespace App\Providers;

use App\Support\CrmCreatorAttribution;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        CrmCreatorAttribution::register();
        // A7.4.12.1: append-only structured audit, in the same DB transaction as source.
        \App\Models\WorkspaceTaskAssignment::observe(\App\Observers\WorkspaceAuditObserver::class);
        \App\Models\WorkspaceCollaborationMember::observe(\App\Observers\WorkspaceAuditObserver::class);
        \App\Models\WorkspaceTaskReview::observe(\App\Observers\WorkspaceAuditObserver::class);
        \App\Models\WorkspaceTask::observe(\App\Observers\WorkspaceAuditObserver::class);
        \App\Models\WorkspaceNotificationPreference::observe(\App\Observers\WorkspaceAuditObserver::class);
        // A7.4.12.2: structured, text-free coverage for schedule and access-rule changes.
        \App\Models\WorkspaceTaskAssignment::observe(\App\Observers\WorkspaceAuditCoverageObserver::class);
        \App\Models\WorkspaceCollaborationMember::observe(\App\Observers\WorkspaceAuditCoverageObserver::class);
        \App\Models\WorkspaceTask::observe(\App\Observers\WorkspaceAuditCoverageObserver::class);
        // A7.5.3.1: append-only CRM status audit for Eloquent transitions.
        \App\Models\Delivery::observe(\App\Observers\CrmCrossModuleStatusAuditObserver::class);
        \App\Models\Installation::observe(\App\Observers\CrmCrossModuleStatusAuditObserver::class);
        // A7.5.3.2: opt-in private CRM status notifications.
        \App\Models\Delivery::observe(\App\Observers\CrmCrossModuleStatusNotificationObserver::class);
        \App\Models\Installation::observe(\App\Observers\CrmCrossModuleStatusNotificationObserver::class);
        // A7.4.11.1: notifications share the same DB transaction as their source action.
        \App\Models\WorkspaceTaskAssignment::observe(\App\Observers\WorkspaceTaskAssignmentNotificationObserver::class);
        \App\Models\WorkspaceCollaborationMember::observe(\App\Observers\WorkspaceCollaborationMemberNotificationObserver::class);
        \App\Models\WorkspaceTaskReview::observe(\App\Observers\WorkspaceTaskReviewNotificationObserver::class);
    }
}
