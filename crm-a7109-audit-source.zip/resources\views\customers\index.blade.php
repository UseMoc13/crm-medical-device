@extends('layouts.app')

@section('title', 'Customers')

@section('content')

<div class="page-head">

    <div>
        <h1>Customers</h1>

        <p>
            Manage customer information and relationships.
        </p>
    </div>

    <div class="actions">

        
{{-- A7105:customers.create --}}
@if(\App\Support\CrmViewAction::allows('customers.create'))
<a
            href="{{ route('customers.create') }}"
            class="btn primary"
        >
            + New Customer
        </a>
@endif
{{-- /A7105 --}}


    </div>

</div>


@if(session('success'))

<div class="alert success">
    {{ session('success') }}
</div>

@endif


<div class="card">

    <div class="card-head">

        <div>
            <h3>Customer List</h3>

            <p>
                {{ $customers->total() }} customers found
            </p>
        </div>

    </div>


    <div class="card-body">


        {{-- =====================================================
             FILTER BAR
        ====================================================== --}}

        <form
            method="GET"
            action="{{ route('customers.index') }}"
            class="customer-filter-bar"
        >

            {{-- Search --}}

            <div class="customer-search">

                <span class="customer-search-icon">
                    ⌕
                </span>

                <input
                    type="text"
                    name="search"
                    value="{{ request('search') }}"
                    placeholder="Search customers..."
                    autocomplete="off"
                >

                @if(request('search'))

                    
{{-- A7105:customers.index --}}
@if(\App\Support\CrmViewAction::allows('customers.index'))
<a
                        href="{{ route('customers.index', request()->except('search', 'page')) }}"
                        class="customer-search-clear"
                        title="Clear search"
                    >
                        ×
                    </a>
@endif
{{-- /A7105 --}}


                @endif

            </div>


            {{-- Customer Type --}}

            <div class="customer-filter-select">

                <select name="customer_type">

                    <option value="">
                        All Types
                    </option>

                    @foreach($customerTypes as $type)

                        <option
                            value="{{ $type }}"
                            @selected(request('customer_type') === $type)
                        >
                            {{ $type }}
                        </option>

                    @endforeach

                </select>

            </div>


            {{-- Status --}}

            <div class="customer-filter-select">

                <select name="status">

                    <option value="">
                        All Status
                    </option>

                    @foreach($statuses as $status)

                        <option
                            value="{{ $status }}"
                            @selected(request('status') === $status)
                        >
                            {{ ucfirst($status) }}
                        </option>

                    @endforeach

                </select>

            </div>


            {{-- Sort --}}

            <div class="customer-filter-select">

                <select name="sort">

                    <option value="created_at" @selected($sort === 'created_at')>
                        Created Date
                    </option>

                    <option value="customer_code" @selected($sort === 'customer_code')>
                        Customer Code
                    </option>

                    <option value="customer_name" @selected($sort === 'customer_name')>
                        Customer Name
                    </option>

                    <option value="customer_type" @selected($sort === 'customer_type')>
                        Customer Type
                    </option>

                    <option value="city" @selected($sort === 'city')>
                        City
                    </option>

                    <option value="province" @selected($sort === 'province')>
                        Province
                    </option>

                    <option value="status" @selected($sort === 'status')>
                        Status
                    </option>

                </select>

            </div>


            {{-- Direction --}}

            <div class="customer-filter-select sort-direction">

                <select name="direction">

                    <option
                        value="asc"
                        @selected($direction === 'asc')
                    >
                        ↑ Ascending
                    </option>

                    <option
                        value="desc"
                        @selected($direction === 'desc')
                    >
                        ↓ Descending
                    </option>

                </select>

            </div>


            {{-- Apply --}}

            <button
                type="submit"
                class="btn customer-filter-button"
            >
                Filter
            </button>


            {{-- Reset --}}

            @if(request()->hasAny([
                'search',
                'status',
                'customer_type',
                'sort',
                'direction'
            ]))

                
{{-- A7105:customers.index --}}
@if(\App\Support\CrmViewAction::allows('customers.index'))
<a
                    href="{{ route('customers.index') }}"
                    class="btn customer-reset-button"
                >
                    Reset
                </a>
@endif
{{-- /A7105 --}}


            @endif

        </form>


        {{-- =====================================================
             ACTIVE FILTER INFORMATION
        ====================================================== --}}

        @if(request('search') || request('customer_type') || request('status'))

            <div class="customer-filter-summary">

                <span>
                    Showing filtered results
                </span>

                @if(request('search'))

                    <span class="filter-chip">
                        Search: "{{ request('search') }}"
                    </span>

                @endif

                @if(request('customer_type'))

                    <span class="filter-chip">
                        Type: {{ request('customer_type') }}
                    </span>

                @endif

                @if(request('status'))

                    <span class="filter-chip">
                        Status: {{ ucfirst(request('status')) }}
                    </span>

                @endif

            </div>

        @endif


        {{-- =====================================================
             CUSTOMER TABLE
        ====================================================== --}}

        <div class="table-wrap">

            <table>
                <thead>
                    <tr>
                        <th class="col-number">No.</th>
                        <th class="col-code">Code</th>
                        <th class="col-customer">Customer</th>
                        <th class="col-type">Type</th>
                        <th class="col-phone">Phone</th>
                        <th class="col-location">Location</th>
                        <th class="col-status">Status</th>
                        <th class="col-date">Created</th>
                        <th class="col-actions">Actions</th>
                    </tr>
                </thead>
                <tbody>

                    @forelse($customers as $customer)

                    <tr>
                        </td>
                            <td class="col-number">
                            {{ $customers->firstItem() + $loop->index }}
                            </td>
                        {{-- Code --}}

                        <td>

                            <strong>
                                {{ $customer->customer_code }}
                            </strong>

                        

                        {{-- Customer --}}

                        <td>

                            
{{-- A7105:customers.show --}}
@if(\App\Support\CrmViewAction::allows('customers.show'))
<a
                                href="{{ route('customers.show', $customer) }}"
                                class="customer-name-link"
                            >

                                <strong>
                                    {{ $customer->customer_name }}
                                </strong>

                            </a>
@endif
{{-- /A7105 --}}


                            @if($customer->email)

                                <div class="muted">
                                    {{ $customer->email }}
                                </div>

                            @endif

                        </td>


                        {{-- Type --}}

                        <td>

                            @if($customer->customer_type)

                                <span class="customer-type-badge">
                                    {{ $customer->customer_type }}
                                </span>

                            @else

                                <span class="muted">
                                    -
                                </span>

                            @endif

                        </td>


                        {{-- Phone --}}

                        <td>
                            {{ $customer->phone ?? '-' }}
                        </td>


                        {{-- Location --}}

                        <td>

                            @if($customer->city || $customer->province)

                                {{ $customer->city }}

                                @if($customer->province)

                                    , {{ $customer->province }}

                                @endif

                            @else

                                -

                            @endif

                        </td>


                        {{-- Status --}}

                        <td>

                            <span class="status-badge status-{{ strtolower($customer->status) }}">

                                {{ ucfirst($customer->status) }}

                            </span>

                        </td>


                        {{-- Created --}}

                        <td>

                            {{ $customer->created_at?->format('d M Y') }}

                        </td>


                        {{-- Actions --}}

                        <td>
                                <div class="table-actions">
                                    
{{-- A7105:customers.show --}}
@if(\App\Support\CrmViewAction::allows('customers.show'))
<a
                                        href="{{ route('customers.show', $customer->customer_id) }}"
                                        class="action-btn view"
                                        title="View"
                                        aria-label="View Customer"
                                    >
                                        <svg viewBox="0 0 24 24" aria-hidden="true">
                                            <path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/>
                                            <circle cx="12" cy="12" r="3"/>
                                        </svg>
                                    </a>
@endif
{{-- /A7105 --}}


                                    
{{-- A7105:customers.edit --}}
@if(\App\Support\CrmViewAction::allows('customers.edit'))
<a
                                        href="{{ route('customers.edit', $customer->customer_id) }}"
                                        class="action-btn edit"
                                        title="Edit"
                                        aria-label="Edit Customer"
                                    >
                                        <svg viewBox="0 0 24 24" aria-hidden="true">
                                            <path d="M12 20h9"/>
                                            <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"/>
                                        </svg>
                                    </a>
@endif
{{-- /A7105 --}}


                                    
{{-- A7105:customers.destroy --}}
@if(\App\Support\CrmViewAction::allows('customers.destroy'))
<form
                                        action="{{ route('customers.destroy', $customer->customer_id) }}"
                                        method="POST"
                                        onsubmit="return confirm('Are you sure you want to delete this Customer?')"
                                    >
                                        @csrf
                                        @method('DELETE')

                                        <button
                                            type="submit"
                                            class="action-btn delete"
                                            title="Delete"
                                            aria-label="Delete Customer"
                                        >
                                            <svg viewBox="0 0 24 24" aria-hidden="true">
                                                <path d="M3 6h18"/>
                                                <path d="M8 6V4h8v2"/>
                                                <path d="m19 6-1 14H6L5 6"/>
                                                <path d="M10 11v5M14 11v5"/>
                                            </svg>
                                        </button>
                                    </form>
@endif
{{-- /A7105 --}}

                                </div>
                            </td>

                    </tr>


                    @empty

                    <tr>

                        <td colspan="9">

                            <div class="empty">

                                No customers found.

                            </div>

                        </td>

                    </tr>

                    @endforelse

                </tbody>

            </table>

        </div>


        {{-- =====================================================
             PAGINATION
        ====================================================== --}}

        @if($customers->hasPages())

            <div class="pagination">

                {{ $customers->links() }}

            </div>

        @endif

        <div class="table-footer">
            <div>
                Showing {{ $customers->firstItem() ?? 0 }}
                to {{ $customers->lastItem() ?? 0 }}
                of {{ $customers->total() }} Customers
            </div>
    </div>

</div>


{{-- =========================================================
     DELETE CONFIRMATION MODAL
========================================================= --}}

<div
    class="delete-modal"
    id="deleteCustomerModal"
    aria-hidden="true"
>

    <div
        class="delete-modal-overlay"
        data-close-delete-modal
    ></div>


    <div
        class="delete-modal-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="deleteModalTitle"
    >

        <div class="delete-modal-icon">
            !
        </div>


        <div class="delete-modal-content">

            <h3 id="deleteModalTitle">
                Delete Customer?
            </h3>

            <p>
                Are you sure you want to delete
                <strong id="deleteCustomerName"></strong>?
            </p>

            <span>
                This action cannot be undone.
            </span>

        </div>


        <div class="delete-modal-actions">

            <button
                type="button"
                class="btn"
                id="cancelDeleteCustomer"
            >
                Cancel
            </button>

            <button
                type="button"
                class="btn delete-confirm-button"
                id="confirmDeleteCustomer"
            >
                Delete Customer
            </button>

        </div>

    </div>

</div>


<style>

/* =========================================================
   CUSTOMER TABLE - COMPLETE BORDERS
========================================================= */

.table-wrap {
    width: 100%;
    overflow-x: auto;
    border: 1px solid #dce3ed;
    border-radius: 8px;
}

.table-wrap table {
    width: 100%;
    border-collapse: collapse;
    border-spacing: 0;
    border: none;
}

/* Table Header */
.table-wrap table thead th {
    padding: 14px 12px;
    background: #f8f9fc;
    color: #64748b;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.4px;
    text-align: left;
    white-space: nowrap;

    border: 1px solid #e1e6ef;
    border-top: none;
}

/* Table Body */
.table-wrap table tbody td {
    padding: 13px 12px;
    font-size: 12px;
    color: #17284f;
    vertical-align: middle;

    border: 1px solid #e1e6ef;
}

/* Left Border */
.table-wrap table thead th:first-child,
.table-wrap table tbody td:first-child {
    border-left: none;
}

/* Right Border */
.table-wrap table thead th:last-child,
.table-wrap table tbody td:last-child {
    border-right: none;
}

/* Bottom Border */
.table-wrap table tbody tr:last-child td {
    border-bottom: none;
}

/* Row Hover */
.table-wrap table tbody tr:hover {
    background: #f8fafc;
}

/* Actions Column */
.table-wrap table th:last-child,
.table-wrap table td:last-child {
    text-align: center;
    min-width: 130px;
}

/* Empty State */
.table-wrap table tbody td[colspan] {
    text-align: center;
    padding: 28px 12px;
}

.action-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 34px;
        height: 34px;
        padding: 7px;
        border: 1px solid #e5e7eb;
        border-radius: 7px;
        background: #fff;
        cursor: pointer;
        text-decoration: none;
    }

    .action-btn svg {
        width: 17px;
        height: 17px;
        fill: none;
        stroke: currentColor;
        stroke-width: 1.8;
        stroke-linecap: round;
        stroke-linejoin: round;
    }

    .action-btn.view {
        color: #2563eb;
    }

    .action-btn.edit {
        color: #d97706;
    }

    .action-btn.delete {
        color: #dc2626;
    }

.table-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 16px;
        flex-wrap: wrap;
        margin-top: 18px;
        color: #6b7280;
        font-size: 13px;
    }

    .table-footer {
            align-items: flex-start;
            flex-direction: column;
        }

/* Responsive */
@media (max-width: 768px) {
    .table-wrap table {
        min-width: 950px;
    }
}

/* =========================================================
   CUSTOMER FILTER BAR
========================================================= */

.customer-filter-bar {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
    margin-bottom: 18px;
}


/* Search */

.customer-search {
    position: relative;
    flex: 1 1 260px;
    min-width: 220px;
}

.customer-search input {
    width: 100%;
    height: 40px;
    box-sizing: border-box;

    padding: 0 38px 0 38px;

    border: 1px solid #d9dee8;
    border-radius: 8px;

    background: #fff;

    color: #17284f;
    font-size: 13px;

    transition:
        border-color .18s ease,
        box-shadow .18s ease;
}

.customer-search input:focus {
    outline: none;
    border-color: #2ba7a0;

    box-shadow:
        0 0 0 3px rgba(43, 167, 160, .08);
}

.customer-search-icon {
    position: absolute;

    left: 13px;
    top: 50%;

    transform: translateY(-50%);

    color: #7d8797;

    font-size: 19px;

    pointer-events: none;
}

.customer-search-clear {
    position: absolute;

    right: 10px;
    top: 50%;

    transform: translateY(-50%);

    width: 22px;
    height: 22px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 50%;

    color: #7d8797;
    text-decoration: none;

    font-size: 18px;
}

.customer-search-clear:hover {
    background: #edf1f5;
    color: #17284f;
}


/* =========================================================
   FILTER SELECT
========================================================= */

.customer-filter-select {
    position: relative;
}

.customer-filter-select select {
    min-width: 145px;
    height: 40px;

    padding: 0 34px 0 12px;

    border: 1px solid #d9dee8;
    border-radius: 8px;

    background-color: #fff;

    color: #34415c;

    font-size: 13px;

    cursor: pointer;

    appearance: auto;

    transition:
        border-color .18s ease,
        box-shadow .18s ease;
}

.customer-filter-select select:hover {
    border-color: #b7c0cf;
}

.customer-filter-select select:focus {
    outline: none;

    border-color: #2ba7a0;

    box-shadow:
        0 0 0 3px rgba(43, 167, 160, .08);
}

.sort-direction select {
    min-width: 145px;
}


/* Buttons */

.customer-filter-button {
    height: 40px;
    white-space: nowrap;
}

.customer-reset-button {
    height: 40px;

    display: inline-flex;
    align-items: center;

    white-space: nowrap;
}


/* =========================================================
   FILTER SUMMARY
========================================================= */

.customer-filter-summary {
    display: flex;
    align-items: center;
    gap: 7px;
    flex-wrap: wrap;

    margin-bottom: 15px;

    font-size: 12px;
    color: #7d8797;
}

.filter-chip {
    padding: 5px 9px;

    border-radius: 6px;

    background: #f1f5f7;

    color: #34415c;

    font-size: 11px;
}


/* =========================================================
   CUSTOMER NAME
========================================================= */

.customer-name-link {
    color: inherit;
    text-decoration: none;
}

.customer-name-link:hover {
    color: #223a70;
}


/* =========================================================
   CUSTOMER TYPE BADGE
========================================================= */

.customer-type-badge {
    display: inline-flex;

    align-items: center;

    padding: 4px 8px;

    border-radius: 6px;

    background: #f1f5f7;

    color: #34415c;

    font-size: 11px;

    font-weight: 600;
}


/* =========================================================
   STATUS
========================================================= */

.status-badge.status-active {
    background: #e8f5f0;
    color: #16805f;
}

.status-badge.status-inactive {
    background: #f2f3f5;
    color: #737b89;
}


/* =========================================================
   DELETE MODAL
========================================================= */

.delete-modal {
    position: fixed;

    inset: 0;

    z-index: 9999;

    display: none;

    align-items: center;
    justify-content: center;
}

.delete-modal.open {
    display: flex;
}

.delete-modal-overlay {
    position: absolute;

    inset: 0;

    background: rgba(15, 24, 42, .45);

    backdrop-filter: blur(2px);
}

.delete-modal-dialog {
    position: relative;

    width: min(420px, calc(100% - 32px));

    background: #fff;

    border-radius: 14px;

    padding: 26px;

    box-shadow:
        0 20px 60px rgba(23, 40, 79, .20);

    animation: deleteModalIn .18s ease;
}

@keyframes deleteModalIn {

    from {
        opacity: 0;
        transform: translateY(8px) scale(.98);
    }

    to {
        opacity: 1;
        transform: translateY(0) scale(1);
    }

}

.delete-modal-icon {
    width: 44px;
    height: 44px;

    display: flex;
    align-items: center;
    justify-content: center;

    margin-bottom: 16px;

    border-radius: 50%;

    background: #fff0f0;

    color: #c94a4a;

    font-size: 21px;

    font-weight: 700;
}

.delete-modal-content h3 {
    margin: 0 0 8px;

    color: #17284f;

    font-size: 18px;
}

.delete-modal-content p {
    margin: 0 0 6px;

    color: #34415c;

    font-size: 13px;

    line-height: 1.6;
}

.delete-modal-content p strong {
    color: #17284f;
}

.delete-modal-content > span {
    color: #8a94a6;

    font-size: 12px;
}

.delete-modal-actions {
    display: flex;

    justify-content: flex-end;

    gap: 8px;

    margin-top: 24px;
}

.delete-confirm-button {
    background: #c94a4a !important;
    color: #fff !important;

    border-color: #c94a4a !important;
}

.delete-confirm-button:hover {
    background: #b83f3f !important;
    border-color: #b83f3f !important;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 900px) {

    .customer-search {
        flex: 1 1 100%;
    }

    .customer-filter-select {
        flex: 1 1 150px;
    }

    .customer-filter-select select {
        width: 100%;
    }

}


@media (max-width: 600px) {

    .customer-filter-bar {
        flex-direction: column;
        align-items: stretch;
    }

    .customer-search,
    .customer-filter-select,
    .customer-filter-button,
    .customer-reset-button {
        width: 100%;
    }

    .customer-filter-button,
    .customer-reset-button {
        justify-content: center;
    }

    .delete-modal-dialog {
        padding: 22px;
    }

    .delete-modal-actions {
        flex-direction: column-reverse;
    }

    .delete-modal-actions .btn {
        width: 100%;
        justify-content: center;
    }

    }
    .col-number {
    width: 55px;
    min-width: 55px;
    max-width: 55px;
    text-align: center !important;
    white-space: nowrap;
    }

    .col-code {
        min-width: 120px;
    }

    .col-customer {
        min-width: 180px;
    }

    .col-type {
        min-width: 110px;
    }

    .col-phone {
        min-width: 140px;
        white-space: nowrap;
    }

    .col-location {
        min-width: 180px;
    }

    .col-status {
        min-width: 110px;
    }

    .col-date {
        min-width: 140px;
        white-space: nowrap;
    }

    .col-actions {
        width: 130px;
        min-width: 130px;
        text-align: center !important;
    }

</style>


<script>

/* =========================================================
   DELETE CONFIRMATION
========================================================= */

document.addEventListener('DOMContentLoaded', function () {

    const modal =
        document.getElementById('deleteCustomerModal');

    const customerName =
        document.getElementById('deleteCustomerName');

    const confirmButton =
        document.getElementById('confirmDeleteCustomer');

    const cancelButton =
        document.getElementById('cancelDeleteCustomer');

    const closeOverlay =
        document.querySelector('[data-close-delete-modal]');

    let deleteForm = null;


    function openDeleteModal(form) {

        deleteForm = form;

        const name =
            form.dataset.customerName || 'this customer';

        customerName.textContent = name;

        modal.classList.add('open');

        modal.setAttribute(
            'aria-hidden',
            'false'
        );

        document.body.style.overflow = 'hidden';

    }


    function closeDeleteModal() {

        modal.classList.remove('open');

        modal.setAttribute(
            'aria-hidden',
            'true'
        );

        document.body.style.overflow = '';

        deleteForm = null;

    }


    document
        .querySelectorAll('.delete-form')
        .forEach(function (form) {

            form.addEventListener(
                'submit',
                function (event) {

                    event.preventDefault();

                    openDeleteModal(form);

                }
            );

        });


    confirmButton.addEventListener(
        'click',
        function () {

            if (deleteForm) {

                deleteForm.submit();

            }

        }
    );


    cancelButton.addEventListener(
        'click',
        closeDeleteModal
    );


    closeOverlay.addEventListener(
        'click',
        closeDeleteModal
    );


    document.addEventListener(
        'keydown',
        function (event) {

            if (
                event.key === 'Escape' &&
                modal.classList.contains('open')
            ) {

                closeDeleteModal();

            }

        }
    );

});

</script>

@endsection