@extends('layouts.app')
@section('title', 'Create Contract')
@section('content')
<div class="page-head"><div><h1>Create Contract</h1><p>Register a contract and associate it with a sales order.</p></div><div class="actions">
{{-- A7105:contracts.index --}}
@if(\App\Support\CrmViewAction::allows('contracts.index'))
<a href="{{ route('contracts.index') }}" class="btn">← Back to Contracts</a>
@endif
{{-- /A7105 --}}
</div></div>
@if($errors->any())<div class="alert danger"><strong>Please correct the following errors:</strong><ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
@include('contracts._form')
@endsection
