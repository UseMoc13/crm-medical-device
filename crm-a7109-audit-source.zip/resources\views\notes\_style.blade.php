<style>
/* A7.4.10 Personal Notes. Reuses the CRM Navy (#17284f) and Teal (#168a82) palette. */
.notes-stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px;margin-bottom:19px}.notes-stat{padding:20px!important}.notes-stat span{display:block;color:#7d8797;font-size:11px;font-weight:650}.notes-stat strong{display:block;color:#17284f;font-size:26px;margin:4px 0}.notes-stat small{font-size:10px;color:#929eae}.notes-filter{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:19px}.notes-filter input[type=search]{flex:1 1 260px}.notes-filter input[type=search],.notes-filter select{min-height:40px;padding:9px 11px;border:1px solid #d9e2ec;border-radius:8px;background:#fff;font-size:12px;color:#23334f}.notes-filter-check{display:inline-flex;align-items:center;gap:7px;font-size:12px;color:#5a6a80}.notes-filter-check input{accent-color:#168a82}.notes-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.notes-item{display:flex;flex-direction:column;gap:10px;padding:18px;border:1px solid #e5eaf1;border-radius:12px;background:#fff;min-height:175px;min-width:0;transition:border-color .15s,box-shadow .15s}.notes-item:hover{border-color:#b4ded2;box-shadow:0 8px 22px #17284f0c}.notes-item-head{display:flex;align-items:center;justify-content:space-between}.notes-icon{display:grid;place-items:center;background:#eaf7f3;color:#16836a;width:38px;height:38px;border-radius:10px;font-size:18px}.notes-badges{display:flex;gap:5px}.notes-badge{display:inline-block;border-radius:6px;padding:5px 9px;background:#f1f3f8;color:#65748b;font-size:10px;font-weight:750}.notes-badge.pinned{background:#e8f5ef;color:#16826b}.notes-item-title{display:block;font-weight:750;font-size:13px;color:#17284f;text-decoration:none;overflow-wrap:anywhere}.notes-item-title:hover{text-decoration:underline}.notes-item p{font-size:11px;color:#738197;line-height:1.65;margin:0;overflow-wrap:anywhere;flex:1}.notes-item-foot{display:flex;justify-content:space-between;gap:10px;align-items:center;border-top:1px solid #eef1f5;padding-top:12px}.notes-item-foot small{font-size:10px;color:#93a0af}.notes-item-foot a{font-size:11px;color:#16826b;text-decoration:none;font-weight:700}.notes-empty{grid-column:1/-1;padding:45px;text-align:center;color:#8290a4}.notes-empty>div{font-size:32px;color:#16826b}.notes-empty h3{font-size:15px;color:#17284f;margin:10px 0}.notes-empty p{font-size:12px}.notes-pagination{margin-top:19px}
.notes-editor-grid,.notes-detail-grid{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(280px,.85fr);gap:20px;align-items:start}.notes-editor-side{display:grid;gap:18px}.notes-fields,.notes-editor-side .card-body{padding:21px!important}.notes-field{margin-bottom:18px}.notes-field label{display:block;color:#53647d;font-size:11px;font-weight:700;margin-bottom:8px}.notes-field label span{color:#c94a4a}.notes-field input,.notes-field select,.notes-field textarea{display:block;width:100%;min-height:42px;box-sizing:border-box;padding:10px 12px;border:1px solid #d9e2ec;border-radius:8px;background:#fff;color:#17284f;font:inherit;font-size:12px}.notes-field textarea{min-height:230px;resize:vertical;line-height:1.7}.notes-field :is(input,textarea,select):focus{outline:none;border-color:#168a82;box-shadow:0 0 0 3px #168a821a}.notes-field small{color:#c04450;font-size:11px}.notes-two-col{display:grid;grid-template-columns:1fr 1fr;gap:12px}.notes-check{display:flex;align-items:center;gap:9px;font-size:12px;color:#50617a}.notes-check input{accent-color:#168a82}.notes-help{color:#8794a6;font-size:11px;line-height:1.6;margin:0}.notes-editor-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:20px}.notes-detail-identity{display:flex;align-items:center;gap:14px;margin-bottom:19px}.notes-detail-icon{display:grid;place-items:center;width:52px;height:52px;background:#eaf7f3;color:#16826b;border-radius:12px;font-size:24px}.notes-detail-identity h2{font-size:19px;color:#17284f;margin:0 0 5px;overflow-wrap:anywhere}.notes-detail-identity small{color:#8794a6;font-size:11px}.notes-note-body{white-space:pre-wrap;overflow-wrap:anywhere;border:1px solid #e5eaf1;background:#f9fbfd;border-radius:9px;padding:21px;color:#42526e;font-size:12px;line-height:1.8;min-height:120px}.notes-detail-meta{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:13px;margin-top:20px}.notes-detail-meta>div{padding:13px;border:1px solid #e9edf3;border-radius:9px}.notes-detail-meta span,.notes-relation span{display:block;color:#8895a6;font-size:11px;margin-bottom:5px}.notes-detail-meta strong{color:#243650;font-size:12px;overflow-wrap:anywhere}.notes-relation{margin-bottom:18px;padding-bottom:16px;border-bottom:1px solid #edf1f5}.notes-relation:last-child{border:0;margin-bottom:0;padding-bottom:0}.notes-relation strong,.notes-relation a{color:#17284f;font-size:12px;font-weight:700;overflow-wrap:anywhere}.notes-relation a{color:#16826b}.notes-actions-card{margin-top:19px}.notes-action-row{display:flex;gap:10px;flex-wrap:wrap;align-items:center}.notes-action-row form{margin:0}.notes-danger{color:#ba4451!important;border-color:#ebc0c5!important}.notes-danger:hover{background:#fff2f3!important}
.notes-topbar-menu{position:relative;display:flex;align-items:center;z-index:210}.notes-topbar-toggle{list-style:none;display:flex;align-items:center;justify-content:center;cursor:pointer}.notes-topbar-toggle::-webkit-details-marker{display:none}.notes-topbar-menu[open] .notes-topbar-toggle{background:#eaf7f3;color:#167d70}.notes-topbar-panel{position:absolute;right:0;top:calc(100% + 13px);width:min(345px,calc(100vw - 30px));background:#fff;border:1px solid #dce4ee;border-radius:12px;box-shadow:0 18px 50px #17284f29;overflow:hidden;z-index:4000}.notes-topbar-head{padding:17px;display:flex;align-items:center;justify-content:space-between;gap:10px;border-bottom:1px solid #edf1f5}.notes-topbar-head strong{display:block;color:#17284f;font-size:13px}.notes-topbar-head small{display:block;color:#8794a6;margin-top:3px;font-size:10px}.notes-topbar-head .btn{font-size:11px;padding:8px 11px}.notes-topbar-items{max-height:315px;overflow:auto}.notes-topbar-item{display:block;text-decoration:none;padding:12px 17px;border-bottom:1px solid #f1f3f7}.notes-topbar-item:hover{background:#f5faf8}.notes-topbar-item strong{display:block;font-size:12px;color:#17284f;overflow-wrap:anywhere}.notes-topbar-item small{display:block;font-size:10px;color:#8693a5;margin-top:4px;overflow-wrap:anywhere}.notes-topbar-empty{padding:18px;color:#8794a6;font-size:11px;line-height:1.6;margin:0}.notes-topbar-all{display:block;text-align:center;color:#167d70;text-decoration:none;font-size:11px;font-weight:750;padding:13px;background:#f8fafb}.notes-topbar-all:hover{background:#eaf7f3}
.notes-linked-card{margin:18px 0}.notes-linked-card .card-head{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}.notes-linked-card .card-head .btn{font-size:11px}.notes-linked-list{display:grid;gap:9px}.notes-linked-list>a{padding:12px 14px;border:1px solid #e8edf3;border-radius:9px;text-decoration:none;background:#fafcfd}.notes-linked-list>a:hover{border-color:#a7d8cb;background:#f3faf6}.notes-linked-list strong{color:#17284f;font-size:12px;display:block}.notes-linked-list small{color:#8794a6;font-size:11px;display:block;margin-top:5px}.notes-linked-list p{font-size:12px;color:#8491a3;margin:0}
@media(max-width:1080px){.notes-cards{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:830px){.notes-editor-grid,.notes-detail-grid{grid-template-columns:1fr}.notes-stats{grid-template-columns:repeat(3,minmax(0,1fr))}}@media(max-width:640px){.notes-cards,.notes-stats{grid-template-columns:1fr}.notes-two-col{grid-template-columns:1fr}.notes-filter>*{width:100%;max-width:none!important}.notes-filter-check{width:auto}.notes-topbar-panel{right:-60px}.notes-detail-meta{grid-template-columns:1fr}}

/* A7.4.10.1 Global floating Sticky Notes — private, responsive, draggable. */
.notes-global-trigger{display:inline-flex;align-items:center;justify-content:center}
.notes-floating{position:fixed;z-index:49000;width:590px;height:540px;min-width:340px;min-height:230px;max-width:calc(100vw - 12px);max-height:calc(100vh - 12px);background:#fff;border:1px solid #d8e2eb;border-radius:13px;box-shadow:0 18px 65px rgba(21,38,75,.24);overflow:auto;resize:both;display:flex;flex-direction:column;color:#17284f}
.notes-floating[hidden]{display:none!important}.notes-floating.is-minimized{height:52px!important;min-height:52px!important;resize:none;overflow:hidden}.notes-floating.is-minimized .notes-floating-content{display:none}
.notes-floating-head{height:52px;min-height:52px;display:flex;align-items:center;justify-content:space-between;gap:12px;background:#f3f8f8;border-bottom:1px solid #e2eaef;padding:8px 12px;cursor:grab;user-select:none;touch-action:none;box-sizing:border-box}.notes-floating-head:active{cursor:grabbing}
.notes-floating-brand{display:flex;align-items:center;gap:9px}.notes-floating-brand>span{display:grid;place-items:center;border-radius:9px;background:#e1f1ec;color:#128165;height:29px;width:29px;font-size:17px}.notes-floating-brand strong{display:block;font-size:12px}.notes-floating-brand small{display:block;color:#8190a0;font-size:10px;margin-top:2px}.notes-floating-head-actions{display:flex;gap:4px}.notes-floating-head-actions button{border:0;background:transparent;color:#64748b;cursor:pointer;border-radius:6px;width:29px;height:29px;font-size:22px}.notes-floating-head-actions button:hover{background:#e2ebf0;color:#17284f}
.notes-floating-content{flex:1;min-height:0;display:flex;flex-direction:column;overflow:hidden}.notes-floating-toolbar{display:flex;gap:8px;padding:10px;border-bottom:1px solid #edf1f4}.notes-floating-search-wrap{flex:1;min-width:0}.notes-floating-search-wrap input{height:34px;width:100%;border:1px solid #dce5eb;border-radius:7px;box-sizing:border-box;padding:0 10px;font-size:11px;font-family:inherit}.notes-floating-new{white-space:nowrap;font-size:11px;padding:7px 10px!important}
.notes-floating-workspace{flex:1;display:flex;min-height:0;position:relative}.notes-floating-list{width:35%;min-width:116px;border-right:1px solid #e6edf2;background:#f8fafb;overflow-y:auto;padding:5px;box-sizing:border-box}.notes-floating-list-item{display:block;width:100%;text-align:left;border:1px solid transparent;background:transparent;border-radius:7px;padding:10px;cursor:pointer;margin-bottom:3px;font-family:inherit}.notes-floating-list-item:hover{background:#eef7f4}.notes-floating-list-item.active{background:#eaf5f1;border-color:#bddfd2}.notes-floating-list-item strong{font-size:11px;color:#17284f;display:block;overflow-wrap:anywhere}.notes-floating-list-item small{color:#8b96a4;font-size:10px;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:4px}.notes-floating-list-empty{font-size:11px;color:#8191a1;padding:12px}
.notes-floating-editor{position:relative;box-sizing:border-box;flex:1;min-width:0;overflow-y:auto;padding:12px;display:flex;flex-direction:column;gap:8px}.notes-floating-editor[hidden],.notes-floating-empty[hidden]{display:none!important}.notes-floating-empty{flex:1;display:grid;place-items:center;font-size:12px;color:#8292a0;text-align:center;padding:20px}.notes-floating-label{display:block;font-size:11px;font-weight:700;color:#243653}.notes-floating-editor input,.notes-floating-editor textarea,.notes-mention-picker select{font-family:inherit;background:#fff;border:1px solid #dce5eb;border-radius:7px;color:#17284f;box-sizing:border-box}.notes-floating-editor input{padding:9px;width:100%;font-size:12px}.notes-floating-editor textarea{resize:vertical;min-height:114px;width:100%;font-size:12px;line-height:1.6;padding:10px}.notes-floating-editor-row{display:flex;justify-content:space-between;gap:8px;align-items:center}.notes-floating-hint{font-size:10px;color:#8391a2}.notes-floating-textarea-wrap{position:relative}.notes-mention-picker{position:absolute;z-index:10;left:0;right:0;top:100%;background:#fff;border:1px solid #cbdde1;box-shadow:0 10px 20px rgba(22,42,70,.16);border-radius:8px;max-height:200px;overflow:auto}.notes-mention-picker[hidden]{display:none}.notes-mention-header{display:flex;align-items:center;justify-content:space-between;gap:6px;padding:7px 10px;background:#f4f8fb;position:sticky;top:0}.notes-mention-header strong{font-size:10px}.notes-mention-header select{max-width:100px;font-size:10px;padding:4px}.notes-mention-results{font-size:11px;color:#7d8b9b}.notes-mention-results button{width:100%;display:flex;align-items:flex-start;gap:6px;flex-direction:column;border:0;background:#fff;text-align:left;padding:8px 10px;cursor:pointer;color:#253552}.notes-mention-results button:hover{background:#eef9f6}.notes-mention-results button small{color:#278270}.notes-mention-results button strong{font-size:11px;font-weight:600}.notes-floating-preview-caption{font-size:10px;font-weight:750;color:#5b6c7d}.notes-floating-preview{min-height:44px;white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.6;border:1px solid #e7ebf0;border-radius:7px;background:#f9fafc;font-size:11px;padding:9px;color:#38445b}.notes-floating-preview p{margin:0;color:#98a2b3}.notes-mention-link{color:#117e82;text-decoration:underline;text-underline-offset:2px;font-weight:650}.notes-mention-link:hover{color:#075e5e}.notes-floating-preview.is-pending .notes-mention-link{opacity:.65;pointer-events:none}.notes-mention-unavailable{color:#8391a0;text-decoration:line-through}.notes-floating-footer{border-top:1px solid #edf0f4;padding-top:10px;margin-top:auto;display:flex;flex-wrap:wrap;align-items:center;gap:8px;justify-content:space-between}.notes-floating-save-status{font-size:10px;color:#579074}.notes-floating-save-status.error{color:#b6424e;font-weight:650}.notes-floating-editor-actions{display:flex;flex-wrap:wrap;gap:5px}.notes-floating-editor-actions .btn{font-size:10px;padding:6px 8px!important}.notes-floating-delete{color:#b84250;border-color:#edc6ca!important}.notes-floating-bottom{padding:9px 12px;border-top:1px solid #e7edf1;display:flex;justify-content:space-between;align-items:center;gap:8px;font-size:10px;color:#7e8d9a}.notes-floating-bottom a{color:#168575;text-decoration:none}.notes-floating-confirm{position:absolute;bottom:12px;right:12px;left:12px;border:1px solid #efcaca;background:#fff8f8;box-shadow:0 8px 20px rgba(0,0,0,.12);padding:12px;border-radius:10px;z-index:12}.notes-floating-confirm[hidden]{display:none}.notes-floating-confirm strong{font-size:12px}.notes-floating-confirm p{font-size:11px;margin:5px 0 10px}.notes-floating-confirm>div{display:flex;gap:6px;justify-content:flex-end}.notes-floating:focus-within{border-color:#bcd8d5}
@media(max-width:700px){.notes-floating{position:fixed!important;left:0!important;right:0!important;bottom:0!important;top:auto!important;width:100vw!important;height:min(88dvh,720px)!important;min-width:0;max-width:none;max-height:90dvh;border-radius:16px 16px 0 0;resize:none}.notes-floating.is-minimized{height:52px!important}.notes-floating-head{cursor:default;touch-action:auto}.notes-floating-list{width:32%;min-width:100px}.notes-floating-editor{padding:10px}.notes-floating-brand small{display:none}}


/* A7.4.10.3 Notes UX refinement: simple forms, inline mention links, adjustable split pane. */
.notes-editor-simple{width:100%;max-width:1100px}.notes-editor-simple .card-body{padding:24px!important}.notes-editor-simple .notes-field{margin-bottom:18px}
.notes-page-body-wrap{position:relative}.notes-raw-text.is-enhanced{display:none!important}
.notes-rich-editor{display:block;width:100%;padding:12px 13px;box-sizing:border-box;border:1px solid #dce5eb;border-radius:8px;background:#fff;color:#17284f;font:inherit;font-size:12px;line-height:1.7;white-space:pre-wrap;overflow-wrap:anywhere;outline:0;cursor:text}
.notes-rich-editor:focus{border-color:#168a82;box-shadow:0 0 0 3px #168a821b}.notes-rich-editor[hidden]{display:none!important}
.notes-rich-editor:empty:before{content:attr(data-placeholder);color:#9ba8b6;pointer-events:none}
.notes-page-rich{min-height:330px;max-height:70vh;overflow:auto}
.notes-floating-rich{min-height:130px;flex:1;max-height:none;overflow-y:auto}
.notes-rich-editor a.notes-inline-mention{display:inline;color:#087f78;font-weight:700;text-decoration:underline;text-underline-offset:2px;background:#e7f5f0;border-radius:4px;padding:1px 2px;cursor:pointer;white-space:normal}
.notes-rich-editor a.notes-inline-mention:hover{background:#caece0;color:#075850}
.notes-mention-link{color:#07807a;text-decoration:underline;text-underline-offset:2px;font-weight:700}
.notes-simple-detail{max-width:1100px}.notes-simple-detail .notes-note-body{min-height:200px;background:#fff;border-color:#e3eaf0;line-height:1.85;font-size:13px}
.notes-simple-detail .card-head h3{overflow-wrap:anywhere;font-size:16px}
.notes-floating-workspace{display:grid;grid-template-columns:minmax(0,var(--notes-list-width,35%)) 8px minmax(0,1fr);min-height:0}
.notes-floating-list{grid-column:1;grid-row:1;min-width:0;width:auto;border-right:0}
.notes-floating-splitter{grid-column:2;grid-row:1;position:relative;z-index:2;background:#edf1f4;border-left:1px solid #dfe7ec;border-right:1px solid #dfe7ec;cursor:col-resize;touch-action:none;user-select:none}
.notes-floating-splitter::before{content:'';display:block;position:absolute;top:50%;left:50%;width:3px;height:38px;border-left:1px solid #8494a1;border-right:1px solid #8494a1;transform:translate(-50%,-50%);opacity:.7}
.notes-floating-splitter:hover,.notes-floating-splitter:focus-visible{background:#cfe9e0;outline:2px solid #168a82;outline-offset:-2px}
.notes-floating-editor,.notes-floating-empty{grid-column:3;grid-row:1;min-width:0}
.notes-floating-editor{overflow:auto}.notes-floating-textarea-wrap{flex:1;min-height:130px;display:flex;flex-direction:column}
.notes-floating-editor-row{flex-wrap:wrap}.notes-floating-hint{line-height:1.4}
.notes-floating-editor .notes-rich-editor{padding:10px;min-height:130px}
.notes-floating-list-item small{white-space:nowrap}.notes-floating{overflow:auto}
@media(max-width:700px){.notes-floating-list{min-width:0;width:auto}.notes-floating-workspace{grid-template-columns:minmax(0,var(--notes-list-width,35%)) 8px minmax(0,1fr)}.notes-floating-rich{min-height:150px}.notes-page-rich{min-height:250px}}

/* A7.4.10.4 — full-width Create / Edit / Show, keep single Notes stylesheet. */
.notes-editor-form,
.notes-editor-simple,
.notes-simple-detail,
.notes-actions-card{
    width:100%;max-width:none!important;min-width:0;box-sizing:border-box
}
.notes-editor-form .card,.notes-editor-form .card-body,
.notes-simple-detail .card-body,.notes-actions-card .card-body{min-width:0}
.notes-simple-detail .notes-note-body{max-width:none;overflow-wrap:anywhere}

/* Independent vertical note-body resize handle within the floating window. */
.notes-floating-textarea-wrap{
    flex:0 0 auto;
    height:var(--notes-body-height,175px);
    min-height:120px;
    max-height:none;
    overflow:visible;
    display:flex;
    flex-direction:column
}
.notes-floating-editor .notes-rich-editor.notes-floating-rich{
    flex:1 1 auto;min-height:0!important;max-height:none;overflow-y:auto
}
.notes-floating-body-resize{
    box-sizing:border-box;display:flex;flex:0 0 14px;align-items:center;
    justify-content:center;margin-top:2px;border:1px solid #e2e9ee;
    border-radius:0 0 7px 7px;background:#f5f8fa;
    cursor:ns-resize;touch-action:none;user-select:none;
    color:#8095a2
}
.notes-floating-body-resize span{
    display:block;width:35px;height:3px;border-radius:5px;
    background:currentColor;box-shadow:0 -5px 0 currentColor
}
.notes-floating-body-resize:hover,
.notes-floating-body-resize:focus-visible{
    background:#e1f2ed;color:#16836e;outline:2px solid #168a82;outline-offset:-2px
}
@media(max-width:700px){
    .notes-floating-body-resize{min-height:16px;flex-basis:16px}
    .notes-editor-simple,.notes-simple-detail{max-width:none!important}
}


/* A7.4.10.5: Create/Edit mention chooser escapes card overflow via body portal. */
.notes-mention-picker.notes-page-mention-portal{
    position:fixed!important;
    inset:auto auto auto auto;
    right:auto!important;
    left:12px;
    top:12px;
    z-index:50020!important;
    box-sizing:border-box;
    max-width:calc(100vw - 24px);
    max-height:min(310px,calc(100dvh - 24px));
    overflow-y:auto;
    overscroll-behavior:contain;
    background:#fff;
    box-shadow:0 14px 38px rgba(21,38,75,.24);
}
.notes-page-mention-portal .notes-mention-results{max-height:none}
.notes-page-mention-portal .notes-mention-results button{min-height:42px}
.notes-page-mention-portal .notes-mention-results button:focus-visible{
    outline:2px solid #168a82;outline-offset:-2px;background:#eaf7f3
}
@media(max-width:620px){
    .notes-page-mention-portal .notes-mention-header{gap:5px}
}

</style>
